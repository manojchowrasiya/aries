<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php print Settings_model::$db_config['site_title']; ?>: <?php print $template['title']; ?></title>
    <?php print $template['metadata']; ?>

    <link rel="stylesheet" href="<?php print base_url(); ?>css/reset.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php print base_url(); ?>css/adminpanel/style.css" type="text/css" media="screen" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <?php
    $this->load->view('generic/js_base_url');
    $this->load->view('generic/js_language_files');
    ?>
    <script type="text/javascript" src="<?php print base_url(); ?>js/jQuery/jquery-1.6.1.min.js"></script>
    <script type="text/javascript" src="<?php print base_url(); ?>js/jQuery/jquery-qtip-1.0.0-rc3.min.js"></script>
    <script type="text/javascript" src="<?php print base_url(); ?>js/jQuery/jq_functions.js"></script>
    <script type="text/javascript" src="<?php print base_url(); ?>js/jQuery/adminpanel/style.js"></script>

    <link href='http://fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
</head>

<body>
<div id="container">

	<?php print $template['partials']['header']; ?>

        <div id="contentwrapper">
            <div id="contentcolumn">
                    <?php print $template['body']; ?>
            </div>
        </div>

        <div id="leftcolumn">
            <ul id="admin_nav">
                <li><a href="<?php print site_url('adminpanel/site_settings'); ?>">site settings</a></li>
                <li><a href="<?php print site_url('adminpanel/list_members'); ?>">list members</a></li>
                <li><a href="<?php print site_url('adminpanel/add_member'); ?>">add new member</a></li>
                <li><a href="<?php print site_url('adminpanel/backup_export'); ?>">backup and export</a></li>
            </ul>
        </div>

        <div style="clear: left;"></div>

	<?php print $template['partials']['footer']; ?>

</div>
</body>

</html>