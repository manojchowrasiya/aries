<script type="text/javascript">
        /* http://www.jigniter.com/use-your-site-url-or-base-url-in-javascript-functions/comment-page-1/#comment-654 */
    <!--
        var CI = {
          'base_url': '<?php echo base_url(); ?>'
        };
    -->
    </script>
