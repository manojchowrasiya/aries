<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
print form_open('adminpanel/site_settings/update_settings', array('id' => 'settings_form')) ."\r\n";
$this->load->view('generic/flash_error');
?>
<h2>Site settings</h2>
<div class="grey_box">
<div class="form_label"><?php print form_label('Site title', 'site_title'); ?></div>
<p>The site title appears in the title bar as it is used in the &lt;title&gt; tag. Can be a maximum of 60 characters long.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'site_title', 'id' => 'site_title', 'class' => 'input_text', 'value' => Settings_model::$db_config['site_title'])); ?></div>
</div>
<div class="grey_box">
<div class="form_title">Disable whole application</div>
<div class="text_black">Deny access to all pages, both public and private. The main administrator account will still be able to log in. All pages will be inaccessible except for the login page.<?php print form_checkbox(array('name' => 'disable_all', 'value' => 'accept', 'checked' => Settings_model::$db_config['disable_all'] == 1 ? TRUE : "", 'class' => 'checkbox')); ?></div>
<div class="text_black">Text to display when website is disabled:</div>
<div><?php print form_textarea(array('name' => 'site_disabled_text', 'id' => 'site_disabled_text', 'value' => Settings_model::$db_config['site_disabled_text'] )); ?></div>
</div>
<div class="grey_box">
<div class="form_title">Disable login access</div>
<div>Turn off login ability for all members except the main administrator account.<?php print form_checkbox(array('name' => 'login_enabled', 'value' => 'accept', 'checked' => Settings_model::$db_config['login_enabled'] == 1 ? "" : TRUE, 'class' => 'checkbox')); ?></div>
</div>
<div class="grey_box">
<div class="form_title">Disable member registration</div>
<div>Turn off the ability for new people to register on the site.<?php print form_checkbox(array('name' => 'register_enabled', 'value' => 'accept', 'checked' => Settings_model::$db_config['registration_enabled'] == 1 ? "" : TRUE, 'class' => 'checkbox')); ?></div>
</div>
<div class="grey_box">
<div class="form_title">Enable install page</div>
<div>Turn on the installation page, is used to recreate the main administrator account.<?php print form_checkbox(array('name' => 'install_enabled', 'value' => 'accept', 'checked' => Settings_model::$db_config['install_enabled'] == 1 ? TRUE : "", 'class' => 'checkbox')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Members per page', 'members_per_page'); ?></div>
<p>The number of members per page to display on the list members page.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'members_per_page', 'id' => 'members_per_page', 'class' => 'input_text_short', 'value' => Settings_model::$db_config['members_per_page'], 'maxlength' => '3')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Administrator e-mail account', 'admin_email'); ?></div>
<p>Primary application e-mail address to be used for sending e-mails - by default the same as the maid administrator e-mail.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'admin_email', 'id' => 'admin_email', 'class' => 'input_text', 'value' => Settings_model::$db_config['admin_email_address'])); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Post-login display page', 'home_page'); ?></div>
<p>The page to display right after logging in - should be a controller that extends Private_Controller.</p>
<div class="input_box_thin"><?php print form_dropdown('home_page', $private_pages, Settings_model::$db_config['home_page']); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Currently active theme', 'default_theme'); ?></div>
<p>Allows for change of admin folder by selecting the corresponding theme folder name.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'default_theme', 'id' => 'default_theme', 'class' => 'input_text', 'value' => Settings_model::$db_config['default_theme'])); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('ReCaptcha login attempts trigger', 'default_theme'); ?></div>
<p>Shows a reCaptcha form after this many failed login attempts.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'login_attempts', 'id' => 'login_attempts', 'class' => 'input_text_short', 'value' => Settings_model::$db_config['login_attempts'], 'maxlength' => '3')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('ReCaptcha theme', 'recaptcha_theme'); ?></div>
<p>Choose the preferred reCaptcha view style.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'recaptcha_theme', 'id' => 'recaptcha_theme', 'class' => 'input_text', 'value' => Settings_model::$db_config['recaptcha_theme'])); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Cookie expiration', 'cookie_exp'); ?></div>
<p>Cookies set will receive this number in seconds as their future expiry time.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'cookie_exp', 'id' => 'cookie_exp', 'class' => 'input_text', 'value' => Settings_model::$db_config['cookie_expires'])); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Password link expiration', 'password_exp'); ?></div>
<p>Make the reset password activation link expire in this many seconds in the future.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'password_exp', 'id' => 'password_exp', 'class' => 'input_text', 'value' => Settings_model::$db_config['password_link_expires'])); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Activation link expiration', 'activation_exp'); ?></div>
<p>Make the account activation link expire in this many seconds in the future.</p>
<div class="input_box_thin"><?php print form_input(array('name' => 'activation_exp', 'id' => 'activation_exp', 'class' => 'input_text', 'value' => Settings_model::$db_config['activation_link_expires'])); ?></div>
</div>
<?php print form_submit(array('name' => 'site_settings_submit', 'id' => 'site_settings_submit_0', 'value' => 'save all settings', 'class' => 'input_submit')); ?>
<h2>Mail settings</h2>
<div class="grey_box">
<div class="form_title">Protocol</div>
<div class="text_black">PHP mail() &raquo; <?php print form_radio('email_protocol', '1', (Settings_model::$db_config['email_protocol'] == 1 ? TRUE : FALSE)); ?></div>
<div class="text_black">Sendmail &raquo; <?php print form_radio('email_protocol', '2', (Settings_model::$db_config['email_protocol'] == 2 ? TRUE : FALSE)); ?></div>
<div class="text_black">Gmail SMTP &raquo; <?php print form_radio('email_protocol', '3', (Settings_model::$db_config['email_protocol'] == 3 ? TRUE : FALSE)); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Path to sendmail', 'sendmail_path'); ?></div>
<div class="text_black">For most servers this is /usr/sbin/sendmail</div>
<div class="input_box_thin"><?php print form_input(array('name' => 'sendmail_path', 'id' => 'sendmail_path', 'class' => 'input_text', 'value' => Settings_model::$db_config['sendmail_path'])); ?></div>
<div class="form_label"><?php print form_label('SMTP host', 'smtp_host'); ?> ."</div>
<div class="input_box_thin"><?php print form_input(array('name' => 'smtp_host', 'id' => 'smtp_host', 'class' => 'input_text', 'value' => Settings_model::$db_config['smtp_host'])); ?></div>
<div class="form_label"><?php print form_label('SMTP port', 'smtp_port'); ?> ."</div>
<div class="input_box_thin"><?php print form_input(array('name' => 'smtp_port', 'id' => 'smtp_port', 'class' => 'input_text', 'value' => Settings_model::$db_config['smtp_port'])); ?></div>
<div class="form_label"><?php print form_label('SMTP user', 'smtp_user'); ?></div>
<div class="input_box_thin"><?php print form_input(array('name' => 'smtp_user', 'id' => 'smtp_user', 'class' => 'input_text', 'value' => $this->encrypt->decode(Settings_model::$db_config['smtp_user']))); ?></div>
<div class="form_label"><?php print form_label('SMTP password', 'smtp_pass'); ?></div>
<div class="text_black">Will be encrypted before saving to database.</div>
<div class="input_box_thin"><?php print form_input(array('name' => 'smtp_pass', 'id' => 'smtp_pass', 'class' => 'input_text', 'value' => $this->encrypt->decode(Settings_model::$db_config['smtp_pass']))); ?></div>
</div>
<?php print form_submit(array('name' => 'site_settings_submit', 'id' => 'site_settings_submit_1', 'value' => 'save all settings', 'class' => 'input_submit')) ."\r\n";
print form_close() ."\r\n";

print form_open('adminpanel/site_settings/clear_sessions', array('id' => 'sessions_form')) ."\r\n";
if ($this->session->flashdata('sessions_message')) {
    print "<div id=\"error\" class=\"error_box\">". $this->session->flashdata('sessions_message') ."</div>\r\n";
}
?>
<a id="clear_sessions"></a>
<h2>Clear your sessions</h2>
<div class="grey_box">
<div class="text_black">Can be used to gracefully make all members log out by removing their session data.</div>
</div>
<?php print form_submit(array('name' => 'sessions_submit', 'id' => 'sessions_submit', 'value' => 'Clear sessions', 'class' => 'input_submit')) ."\r\n";
print form_close() ."\r\n";
?>