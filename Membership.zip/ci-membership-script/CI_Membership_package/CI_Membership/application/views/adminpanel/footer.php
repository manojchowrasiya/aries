<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="admin_footer">
    <div id="footer_info">
        Created by rakinjakk - &copy; codecanyon.net 2011
    </div>
</div>