<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
<div>
    <h2>List members</h2>
    <h2>Some tools are disabled to prevent abuse</h2>
    <div id="admin">
        <?php $this->load->view('generic/flash_error'); ?>
        <div id="searchbox_heading">
            <ul>
                <li>username</li>
                <li>first name</li>
                <li>last name</li>
                <li>e-mail</li>
            </ul>
        </div>
        <div id="searchbox">
        <?php
        print form_open('adminpanel/list_members/index/username/asc/post/0') ."\r\n";
        ?>
        <ul>
            <li><?php print form_input(array('name' => 'username', 'id' => 'username', 'class' => 'admin_input')); ?></li>
            <li><?php print form_input(array('name' => 'first_name', 'id' => 'first_name', 'class' => 'admin_input')); ?></li>
            <li><?php print form_input(array('name' => 'last_name', 'id' => 'last_name', 'class' => 'admin_input')); ?></li>
            <li><?php print form_input(array('name' => 'email', 'id' => 'email', 'class' => 'admin_input')); ?></li>
            </ul>
        <?php print form_submit(array('name' => 'member_search_submit', 'id' => 'member_search_submit', 'value' => 'Search member', 'class' => 'input_submit')) ."\r\n";
        print form_close() ."\r\n";
        print "Total rows: ". $total_rows;
        ?>
        </div>

        <div class="pagination">
        <?php
        print $this->pagination->create_links();
        ?>
        </div>
        <ul>
            <li class="t_username"><a href="<?php print base_url() ."adminpanel/list_members/index/username/". ($order_by == "username" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "username" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>username</a></li>
            <li class="t_email"><a href="<?php print base_url() ."adminpanel/list_members/index/email/". ($order_by == "email" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "email" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>email</a></li>
            <li class="t_first_name"><a href="<?php print base_url() ."adminpanel/list_members/index/first_name/". ($order_by == "first_name" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "first_name" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>first name</a></li>
            <li class="t_last_name"><a href="<?php print base_url() ."adminpanel/list_members/index/last_name/". ($order_by == "last_name" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "last_name" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>last name</a></li>
            <li class="t_date"><a href="<?php print base_url() ."adminpanel/list_members/index/date_registered/". ($order_by == "date_registered" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "date_registered" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>date registered</a></li>
            <li class="t_date"><a href="<?php print base_url() ."adminpanel/list_members/index/last_login/". ($order_by == "last_login" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "last_login" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>last login</a></li>
            <li class="t_role"><a href="<?php print base_url() ."adminpanel/list_members/index/role_id/". ($order_by == "role_id" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "role_id" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>role</a></li>
            <li class="t_edit_banned"><a href="<?php print base_url() ."adminpanel/list_members/index/banned/". ($order_by == "banned" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "banned" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>banned</a></li>
            <li class="t_edit_active"><a href="<?php print base_url() ."adminpanel/list_members/index/active/". ($order_by == "active" ? ($sort_order == "asc" ? "desc" : "asc" ) : "asc") ."/". $search ."/0"; ?>" <?php print ($order_by == "active" ? ($sort_order == "asc" ? "class=\"asc\"" : "class=\"desc\"" ) : ""); ?>>active</a></li>
        </ul>
    <?php
    $i = 1;
    if (isset($members)) {
    foreach ($members->result() as $member):
    $member->date_registered = date("F j, Y", strtotime($member->date_registered));
    $member->last_login = date("F j, Y", strtotime($member->last_login));
    print form_open('adminpanel/list_members/action_member/'. $member->id .'/'. $offset .'/'. $order_by .'/'. $sort_order .'/'. $search, array('id' => 'edit_member_form'.$i, 'class' => 'edit_member_form')) ."\r\n";
    ?>
    <ul>
    <li class="username"><?php print form_input(array('name' => 'username', 'class' => 'm_username', 'value' => $member->username)); ?></li>
    <li class="checkbox"><?php print form_checkbox(array('name' => 'username_box', 'value' => 'true')); ?></li>
    <li class="email"><?php print form_input(array('name' => 'email', 'class' => 'm_email', 'value' => $member->email)); ?></li>
    <li class="checkbox"><?php print form_checkbox(array('name' => 'email_box', 'value' => 'true')); ?></li>
    <li class="first_name"><?php print form_input(array('name' => 'first_name', 'class' => 'm_first_name', 'value' => $member->first_name)); ?></li>
    <li class="last_name"><?php print form_input(array('name' => 'last_name', 'class' => 'm_last_name', 'value' => $member->last_name)); ?></li>
    <li class="date"><?php print $member->date_registered; ?></li>
    <li class="date"><?php print $member->last_login; ?></li>
    <li class="role"><a href="<?php print site_url(substr($member->role_name, 0, 1) == "a" ? "adminpanel/list_members/demote_member/" : "adminpanel/list_members/promote_member/") . "/". $member->id ."/". $member->username ."/". $offset .'/'. $order_by .'/'. $sort_order .'/'. $search; ?>" class="<?php print (strtolower(substr($member->role_name, 0, 1)) == "a" ? "demote" : "promote"); ?>"><?php print ucfirst(substr($member->role_name, 0, 1)); ?></a></li>
    <li class="edit_banned"><a href="<?php print site_url('adminpanel/list_members/toggle_ban/'. $member->id ."/". $member->username ."/". $offset .'/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $member->banned) ."\" class=\"". ($member->banned == true ? "banned" : "not_banned"); ?>" title="(un)ban account"></a></li>
    <li class="edit_active"><a href="<?php print site_url('adminpanel/list_members/toggle_active/'. $member->id ."/". $member->username ."/". $offset .'/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $member->active) ."\" class=\"". ($member->active == true ? "is_active" : "not_active"); ?>" title="(de)activate account"></a></li>
    <li class="edit_password"><a href="<?php print site_url('adminpanel/edit_password/index/'. $member->id); ?>" class="m_password" title="change password"></a></li>
    <li class="edit_member"><?php print form_submit(array('name' => 'update', 'class' => 'm_update', 'title' => 'update')); ?></li>
    <li class="delete_member"><?php print form_submit(array('name' => 'delete', 'class' => 'm_delete', 'title' => 'delete')); ?></li>
    </ul>
    <?php
    print form_hidden('id', $member->id);
    print form_close() ."\r\n";
    $i++;
    endforeach;
    }
    ?>
    </div>
    <div class="clearboth"></div>
    <div class="pagination">
    <?php
    print $this->pagination->create_links();
    ?>
    </div>
</div>
<div class="clearboth"></div>