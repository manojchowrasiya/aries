<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
print form_open('adminpanel/add_member/add', array('id' => 'add_member_form')) ."\r\n";
$this->load->view('generic/flash_error');
?>
<h2>Add member</h2>
<div class="grey_box">
<div class="form_label"><?php print form_label('First name', 'reg_first_name'); ?></div>
<div class="input_box_thin"><?php print form_input(array('name' => 'first_name', 'id' => 'reg_first_name', 'value' => $this->session->flashdata('first_name'), 'class' => 'input_text qtip_first_name')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Last name', 'reg_last_name'); ?></div>
<div class="input_box_thin"><?php print form_input(array('name' => 'last_name', 'id' => 'reg_last_name', 'value' => $this->session->flashdata('last_name'), 'class' => 'input_text qtip_last_name')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('E-mail address', 'reg_email'); ?></div>
<div class="input_box_thin"><?php print form_input(array('name' => 'email', 'id' => 'reg_email', 'value' => $this->session->flashdata('email'), 'class' => 'input_text qtip_email')); ?></div>
<div id="email_valid"></div>
<div id="email_taken"></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Username', 'reg_username'); ?></div>
<div class="input_box_thin"><?php print form_input(array('name' => 'username', 'id' => 'reg_username', 'value' => $this->session->flashdata('username'), 'class' => 'input_text qtip_username')); ?></div>
<div id="username_valid"></div>
<div id="username_taken"></div>
<div id="username_length"></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Password', 'reg_password'); ?></div>
<div class="input_box_thin"><?php print form_password(array('name' => 'password', 'id' => 'reg_password', 'class' => 'input_text qtip_password')); ?></div>
</div>
<div class="grey_box">
<div class="form_label"><?php print form_label('Confirm password', 'password_confirm'); ?></div>
<div class="input_box_thin"><?php print form_password(array('name' => 'password_confirm', 'id' => 'password_confirm', 'class' => 'input_text')); ?></div>
</div>
<?php print form_submit(array('name' => 'membership_submit', 'id' => 'membership_submit', 'value' => 'add member', 'class' => 'input_submit')) ."<br />\r\n";
print form_close() ."\r\n";
?>