<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
print form_open('adminpanel/backup_export/export_members', array('id' => 'export_members_form')) ."\r\n";
$this->load->view('generic/flash_error');
?>
<h2>Export members list</h2>
<div class="grey_box">
<div class="text_black">This e-mail will be sent to the admin e-mail entered in site settings.</div>
</div>
<?php print form_submit(array('name' => 'export_submit', 'id' => 'export_submit', 'value' => 'Export memberlist', 'class' => 'input_submit')) ."\r\n";
print form_close() ."\r\n";

print form_open('adminpanel/backup_export/export_database', array('id' => 'export_database_form')) ."\r\n";
if ($this->session->flashdata('db_message')) {
    print "<div id=\"error\" class=\"error_box\">". $this->session->flashdata('db_message') ."</div>\r\n";
}
?>
<h2>Backup your database</h2>
<div class="grey_box">
<div class="text_black">This e-mail will be sent to the admin e-mail entered in site settings.</div>
<div class="text_black">WARNING 1: for very large databases this might not be possible and you will have to export directly from the MySQL command line.</div>
<div class="text_black">WARNING 2: you might want to take your MySQL server offline before backing up. Disable site login before doing this.</div>
</div>
<?php print form_submit(array('name' => 'db_backup_submit', 'id' => 'db_backup_submit', 'value' => 'Export database', 'class' => 'input_submit')) ."\r\n";
print form_close() ."\r\n";