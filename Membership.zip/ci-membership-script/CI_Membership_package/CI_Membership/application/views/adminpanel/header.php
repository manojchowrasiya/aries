<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div id="admin_header">
    <div class="floatleft">
        <h2>Admin panel</h2>
    </div>
    <div class="floatright">
        <a href="<?php print site_url('membership/logout'); ?>" title="<?php print $this->lang->line('logout'); ?>"><?php print $this->lang->line('logout'); ?></a> |
        <a href="<?php print site_url('private/home'); ?>" title="<?php print $this->lang->line('home'); ?>"><?php print $this->lang->line('home'); ?></a>
    </div>
</div>
