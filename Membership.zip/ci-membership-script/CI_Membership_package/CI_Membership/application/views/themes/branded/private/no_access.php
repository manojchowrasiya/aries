<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="center">
    <div id="error">You are not authorized to view this page.</div>
    <p class="login_link"><a href="<?php print base_url(); ?>private/home">Home</a></p>
</div>