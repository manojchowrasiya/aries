<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<h2>Public page</h2>
always accessible, no login required