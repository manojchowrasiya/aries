<div id="membership_footer" class="default_footer_style">
    <p>Created by rakinjakk &copy; Envato 2011</p>
</div>