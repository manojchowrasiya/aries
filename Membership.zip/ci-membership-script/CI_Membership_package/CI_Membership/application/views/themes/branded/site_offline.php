<div class="membership_box">
    <p class="text_black"><?php print Settings_model::$db_config['site_disabled_text']; ?></p>
</div>