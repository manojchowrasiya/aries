<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<h2>Private page</h2>
<p>Private_Controller will redirect to login page when no session data is found.</p>