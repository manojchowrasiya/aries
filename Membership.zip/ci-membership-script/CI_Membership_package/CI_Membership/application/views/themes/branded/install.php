<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="center">
<h2>Install</h2>
<?php
print $message;
?>
</div>