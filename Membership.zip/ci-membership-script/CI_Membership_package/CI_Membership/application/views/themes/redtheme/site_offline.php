<div class="redbox_top"></div>
    <div class="redbox_mid">
        <p class="text_black"><?php print Settings_model::$db_config['site_disabled_text']; ?></p>
    </div>
<div class="redbox_bot"></div>