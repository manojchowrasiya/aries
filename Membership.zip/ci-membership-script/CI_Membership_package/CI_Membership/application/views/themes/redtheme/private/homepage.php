<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<h2>Homepage</h2>
<div>
<p><?php print (isset($param1) ? $param1 : ""); ?></p>
<p><?php print (isset($param2) ? $param2 : ""); ?></p>
<p><?php print (isset($param3) ? $param3 : ""); ?></p>
</div>
