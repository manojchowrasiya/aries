<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_settings extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function index() {
        $content_data['private_pages'] = $this->_load_private_pages();
        
        $this->template->set_theme('adminpanel');
        $this->template->set_layout('adminpanel');
        $this->template->title('admin panel :: site settings');
        $this->process_partial('header', 'adminpanel/header');
        $this->process_partial('footer', 'adminpanel/footer');
        $this->process_template_build('adminpanel/site_settings', $content_data);
    }

    private function _load_private_pages() {
        if ($handle = opendir(APPPATH. 'controllers/private')) {
            $pages = array();
            while (false !== ($file = readdir($handle))) {
                $last_four = substr($file, -4);
                $newfile = str_replace(".php", "", $file);
                if ($last_four == ".php") {
                    $pages[$newfile] = $newfile;
                }
            }

            closedir($handle);
            return $pages;
        }

        return false;


    }

    /**
     *
     * update_settings: update settings from adminpanel
     *
     *
     */

    public function update_settings() {
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('site_title', 'Site title', 'trim|required');
        $this->form_validation->set_rules('members_per_page', 'members per page', 'trim|required|numeric');
        $this->form_validation->set_rules('admin_email', 'admin e-mail', 'trim|required|max_length[255]|is_valid_email');
        $this->form_validation->set_rules('home_page', 'home page', 'trim|required');
        $this->form_validation->set_rules('default_theme', 'default theme', 'trim|required');
        $this->form_validation->set_rules('login_attempts', 'login attempts', 'trim|required|numeric');
        $this->form_validation->set_rules('recaptcha_theme', 'recaptcha theme', 'trim|required');
        $this->form_validation->set_rules('sendmail_path', 'sendmail path', 'trim');
        $this->form_validation->set_rules('smtp_host', 'smtp host', 'trim');
        $this->form_validation->set_rules('smtp_port', 'smtp port', 'trim');
        $this->form_validation->set_rules('smtp_user', 'smtp user', 'trim');
        $this->form_validation->set_rules('smtp_pass', 'smtp pass', 'trim');

        if (!$this->form_validation->run()) {
            if (form_error('site_title')) {
                $this->session->set_flashdata('message', form_error('site_title'));
            }elseif (form_error('members_per_page')) {
                $this->session->set_flashdata('message', form_error('members_per_page'));
            }elseif (form_error('disable_login')) {
                $this->session->set_flashdata('message', form_error('disable_login'));
            }elseif (form_error('disable_registration')) {
                $this->session->set_flashdata('message', form_error('disable_registration'));
            }elseif (form_error('items_per_page')) {
                $this->session->set_flashdata('message', form_error('items_per_page'));
            }elseif (form_error('admin_email')) {
                $this->session->set_flashdata('message', form_error('admin_email'));
            }elseif (form_error('home_page')) {
                $this->session->set_flashdata('message', form_error('home_page'));
            }elseif (form_error('default_theme')) {
                $this->session->set_flashdata('message', form_error('default_theme'));
            }elseif (form_error('login_attempts')) {
                $this->session->set_flashdata('message', form_error('login_attempts'));
            }elseif (form_error('recaptcha_theme')) {
                $this->session->set_flashdata('message', form_error('recaptcha_theme'));
            }
            redirect('/adminpanel/site_settings');
            exit();
        }

        $default_theme = FALSE;
        if (file_exists(APPPATH .'themes/'. $this->input->post('default_theme') .'/views/layouts/main.php')) {
            $default_theme = TRUE;
        }else{
            $this->session->set_flashdata('message', sprintf($this->lang->line('main_not_found'), $this->input->post('default_theme')));
            redirect('/adminpanel/site_settings');
            exit();
        }

        $home_page = FALSE;
        if (file_exists(APPPATH .'controllers/private/'. $this->input->post('home_page') .'.php')) {
            $home_page = TRUE;
        }else{
            $this->session->set_flashdata('message', sprintf($this->lang->line('controller_not_found'), $this->input->post('home_page')));
            redirect('/adminpanel/site_settings');
            exit();
        }

        // delete cache before prepping and inserting data
        $this->cache->delete('settings');

        $data = array(
            'login_enabled' => ($this->input->post('login_enabled') == "" ? 1 : 0),
            'register_enabled' => ($this->input->post('register_enabled') == "" ? 1 : 0),
            'install_enabled' => ($this->input->post('install_enabled') == "" ? 0 : 1),
            'members_per_page' => ($this->input->post('members_per_page') > 0 ? $this->input->post('members_per_page') : 10),
            'admin_email' => $this->input->post('admin_email'),
            'home_page' => ($home_page == TRUE ? $this->input->post('home_page') : Settings_model::$db_config['home_page']),
            'default_theme' => ($default_theme == TRUE ? $this->input->post('default_theme') : Settings_model::$db_config['default_theme']),
            'login_attempts' => $this->input->post('login_attempts'),
            'recaptcha_theme' => $this->input->post('recaptcha_theme'),
            'email_protocol' => $this->input->post('email_protocol'),
            'sendmail_path' => $this->input->post('sendmail_path'),
            'smtp_host' => $this->input->post('smtp_host'),
            'smtp_port' => $this->input->post('smtp_port'),
            'smtp_user' => $this->encrypt->encode($this->input->post('smtp_user')),
            'smtp_pass' => $this->encrypt->encode($this->input->post('smtp_pass')),
            'site_title' => $this->input->post('site_title'),
            'cookie_expires' => $this->input->post('cookie_exp'),
            'password_link_expires' => $this->input->post('password_exp'),
            'activation_link_expires' => $this->input->post('activation_exp'),
            'disable_all' => ($this->input->post('disable_all') == "" ? 0 : 1),
            'site_disabled_text' => $this->input->post('site_disabled_text'),
        );

        $this->load->model('adminpanel/site_settings_model');
        if ($this->site_settings_model->save_settings($data)) {
            $this->session->set_flashdata('message', $this->lang->line('settings_update'));
        }

        redirect('/adminpanel/site_settings');
    }

    public function clear_sessions() {
        // call model and delete
        $this->load->model('adminpanel/site_settings_model');
        if ($this->site_settings_model->clear_sessions()) {
            $this->session->set_flashdata('sessions_message', $this->lang->line('sessions_cleared'));
        }else{
            $this->session->set_flashdata('sessions_message', $this->lang->line('sessions_not_cleared'));
        }
            redirect('/adminpanel/site_settings#clear_sessions');
    }

}

/* End of file site_settings.php */
/* Location: ./application/controllers/adminpanel/site_settings.php */