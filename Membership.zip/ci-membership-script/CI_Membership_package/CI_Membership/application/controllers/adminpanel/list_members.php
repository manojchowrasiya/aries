<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class List_members extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();
        // pre-load
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->model('adminpanel/list_members_model');
    }

    /**
     *
     * index
     *
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     * @param int $offset the offset to be used for selecting data
     *
     */

    public function index($order_by = "username", $sort_order = "asc", $search = "all", $offset = 0) {
        if (!is_numeric($offset)) {
            redirect('/adminpanel/list_members');
        }

        $this->load->library('pagination');
        if ($search == "post") {
            $this->session->unset_userdata(array('s_username' => '', 's_first_name' => '', 's_last_name' => '', 's_email' => ''));
            $this->form_validation->set_error_delimiters('', '');
            $this->form_validation->set_rules('username', 'username', 'trim|max_length[16]');
            $this->form_validation->set_rules('first_name', 'first name', 'trim|max_length[40]');
            $this->form_validation->set_rules('last_name', 'last name', 'trim|max_length[60]');
            $this->form_validation->set_rules('email', 'email', 'trim|max_length[255]');

            if (empty($_POST['username']) && empty($_POST['first_name']) && empty($_POST['last_name']) && empty($_POST['email'])) {
                $this->session->set_flashdata('message', $this->lang->line('enter_search_data'));
                redirect('/adminpanel/list_members/');
                exit();
            }elseif (!$this->form_validation->run()) {
                if (form_error('username')) {
                    $this->session->set_flashdata('message', form_error('username'));
                }elseif (form_error('email')) {
                    $this->session->set_flashdata('message', form_error('email'));
                }elseif (form_error('first_name')) {
                    $this->session->set_flashdata('message', form_error('first_name'));
                }elseif (form_error('last_name')) {
                    $this->session->set_flashdata('message', form_error('last_name'));
                }
                redirect('/adminpanel/list_members/');
                exit();
            }

            $search_session = array(
                's_username'  => $this->input->post('username'),
                's_first_name'     => $this->input->post('first_name'),
                's_last_name' => $this->input->post('last_name'),
                's_email' => $this->input->post('email')
            );
            $this->session->set_userdata($search_session);

            $base_url = site_url('adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/session');
            $search_data = array('username' => $this->input->post('username'), 'first_name' => $this->input->post('first_name'), 'last_name' => $this->input->post('last_name'), 'email' => $this->input->post('email'));
            $content_data['total_rows'] = $config['total_rows'] = $this->list_members_model->count_all_search_members($search_data);
            $content_data['search'] = "session";
            if ($config['total_rows'] == 0) {
                $this->session->set_flashdata('message', $this->lang->line('search_data_none_returned'));
            }


        }elseif($search == "session") {
            $base_url = site_url('adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/session');
            $search_data = array('username' => $this->session->userdata('s_username'), 'first_name' => $this->session->userdata('s_first_name'), 'last_name' => $this->session->userdata('s_last_name'), 'email' => $this->session->userdata('s_email'));
            $content_data['total_rows'] = $config['total_rows'] = $this->list_members_model->count_all_search_members($search_data);
            $content_data['search'] = "session";

        }else{
            $unset_search_session = array('s_username' => '', 's_first_name' => '', 's_last_name' => '', 's_email' => '');
            $this->session->unset_userdata($unset_search_session);
            $content_data['total_rows'] = $config['total_rows'] = $this->list_members_model->count_all_members();
            $base_url = site_url('adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/all');
            $search_data = array();
            $content_data['search'] = "all";
        }

        // set content data
        $per_page = Settings_model::$db_config['members_per_page'];
        $data = $this->list_members_model->get_members($per_page, $offset, $order_by, $sort_order, $search_data);
        if (empty($data)) {
            redirect("/adminpanel/list_members");
        }else{
            $content_data['members'] = $data;
        }
        $content_data['offset'] = $offset;
        $content_data['order_by'] = $order_by;
        $content_data['sort_order'] = $sort_order;

        // set pagination config data
        $config['uri_segment'] = '7';
        $config['base_url'] = $base_url;
        $config['per_page'] = Settings_model::$db_config['members_per_page'];
        $config['prev_tag_open'] = ''; // removes &nbsp; at beginning of pagination output
        $this->pagination->initialize($config);

        // set layout data
        $this->template->set_theme('adminpanel');
        $this->template->set_layout('adminpanel');
        $this->template->title('admin panel :: list members');
        $this->process_partial('header', 'adminpanel/header');
        $this->process_partial('footer', 'adminpanel/footer');
        $this->process_template_build('adminpanel/list_members', $content_data);
    }

    public function action_member($id, $offset, $order_by, $sort_order, $search) {
        if (array_key_exists('update', $_POST)) {
            $this->_update_member($id, $offset, $order_by, $sort_order, $search);
        }else{
            $this->_delete_member($id, $offset, $order_by, $sort_order, $search);
        }
    }

    /**
     *
     * _update_member: update member info from adminpanel
     *
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     *
     */

    private function _update_member($id, $offset, $order_by, $sort_order, $search) {
        $this->form_validation->set_error_delimiters('', '');
        if ($this->input->post('username_box') == true) {
            $this->form_validation->set_rules('username', 'username', 'trim|required|max_length[16]|min_length[6]|is_valid_username|is_existing_unique_field[user.username]');
        }
        if ($this->input->post('email_box') == true) {
            $this->form_validation->set_rules('email', 'email', 'trim|required|max_length[255]|is_valid_email|is_existing_unique_field[user.email]');
        }
        $this->form_validation->set_rules('first_name', 'first name', 'trim|required|max_length[40]|min_length[2]');
        $this->form_validation->set_rules('last_name', 'last name', 'trim|required|max_length[60]|min_length[2]');

        $username = $this->list_members_model->get_username_by_id($id);
        if ($username == ADMINISTRATOR && $this->input->post('username_box') == true) {
            $this->session->set_flashdata('message', $this->lang->line('admin_noedit'));
            redirect('/adminpanel/list_members');
            exit();
        }

        if (!$this->form_validation->run()) {
            if (form_error('username')) {
                $this->session->set_flashdata('message', form_error('username'));
            }elseif (form_error('email') && ($this->input->post('email_box') == true)) {
                $this->session->set_flashdata('message', form_error('email'));
            }elseif (form_error('first_name')) {
                $this->session->set_flashdata('message', form_error('first_name'));
            }elseif (form_error('last_name')) {
                $this->session->set_flashdata('message', form_error('last_name'));
            }
            redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
            exit();
        }

        $this->list_members_model->update_member($this->input->post('id'), $this->input->post('username'), $this->input->post('email'), $this->input->post('first_name'), $this->input->post('last_name'), $this->input->post('username_box'), $this->input->post('email_box'));
        $this->session->set_flashdata('message', sprintf($this->lang->line('member_updated'), $this->input->post('username'), $this->input->post('id')));
        redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }

     /**
     *
     * _delete_member: delete member from adminpanel
     *
     * @param int $id the id of the member to be deleted
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     *
     */

    private function _delete_member($id, $offset, $order_by, $sort_order, $search) {
        $username = $this->list_members_model->get_username_by_id($id);
        if ($username == ADMINISTRATOR) {
            $this->session->set_flashdata('message', $this->lang->line('admin_noremove'));
        }elseif ($this->list_members_model->delete_member($id)) {
            $this->session->set_flashdata('message', sprintf($this->lang->line('member_deleted'), $username, $id));
        }
        redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }

    /**
     *
     * demote_member: demote member from adminpanel
     *
     * @param int $id the id of the member to be deleted
     * @param string $username the username of the member involved
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     *
     */

    public function demote_member($id, $username, $offset, $order_by, $sort_order, $search) {
        if ($this->list_members_model->get_username_by_id($id) == ADMINISTRATOR) {
            $this->session->set_flashdata('message', $this->lang->line('admin_nodemote'));
            redirect('/adminpanel/list_members/index');
            return;
        }elseif ($this->list_members_model->demote_member($id)) {
            $this->session->set_flashdata('message', sprintf($this->lang->line('member_demoted'), $username, $id));
        }
       redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }

    /**
     *
     * promote_member: promote member from adminpanel
     *
     * @param int $id the id of the member to be deleted
     * @param string $username the username of the member involved
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     *
     */

    public function promote_member($id, $username, $offset, $order_by, $sort_order, $search) {
        if ($this->list_members_model->get_username_by_id($id) == ADMINISTRATOR) {
            $this->session->set_flashdata('message', $this->lang->line('admin_nodemote'));
            redirect('/adminpanel/list_members/index');
            return;
        }elseif ($this->list_members_model->promote_member($id)) {
            $this->session->set_flashdata('message', sprintf($this->lang->line('member_promoted'), $username, $id));
        }
        redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }

    /**
     *
     * toggle_ban: (un)ban member from adminpanel
     *
     * @param int $id the id of the member to be deleted
     * @param string $username the username of the member involved
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     * @param bool $banned ban or unban?
     *
     */

    public function toggle_ban($id, $username, $offset, $order_by, $sort_order, $search, $banned) {
        if ($this->list_members_model->get_username_by_id($id) == ADMINISTRATOR) {
            $this->session->set_flashdata('message', $this->lang->line('admin_noban'));
            redirect('/adminpanel/list_members/index');
            return;
        }elseif ($this->list_members_model->toggle_ban($id, $banned)) {
            $banned ? $banned = $this->lang->line('unbanned') : $banned = $this->lang->line('banned');
            $this->session->set_flashdata('message', sprintf($this->lang->line('toggle_ban'), $username) . $banned);
        }
        redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }

    /**
     *
     * toggle_active: (de)activate member from adminpanel
     *
     * @param int $id the id of the member to be deleted
     * @param string $username the username of the member involved
     * @param int $offset the offset to be used for selecting data
     * @param int $order_by order by this data column
     * @param string $sort_order asc or desc
     * @param string $search search type, used in index to determine what to display
     * @param bool $active or deactivate?
     *
     */

    public function toggle_active($id, $username, $offset, $order_by, $sort_order, $search, $active) {
        if ($this->list_members_model->get_username_by_id($id) == ADMINISTRATOR) {
            $this->session->set_flashdata('message', $this->lang->line('admin_noactivate'));
            redirect('/adminpanel/list_members/index');
            return;
        }elseif ($this->list_members_model->toggle_active($id, $active)) {
            $active ? $active = $this->lang->line('deactivated') : $active = $this->lang->line('activated');
            $this->session->set_flashdata('message', sprintf($this->lang->line('toggle_active'), $username) . $active);
        }
        redirect('/adminpanel/list_members/index/'. $order_by .'/'. $sort_order .'/'. $search .'/'. $offset);
    }
}

/* End of file list_members.php */
/* Location: ./application/controllers/adminpanel/list_members.php */