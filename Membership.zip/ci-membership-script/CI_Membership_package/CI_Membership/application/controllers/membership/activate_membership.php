<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Activate_membership extends Membership_Controller {

    public function index() {

    }

    /**
     *
     * check: verify and activate account
     *
     * @param int $email the e-mail address that received the activation link
     * @param string $nonce the member nonce associated with the e-mail address
     *
     */

    public function check($email = NULL, $nonce = NULL) {
        $layout_data['page_title'] = "Activate Membership";

        $content_data['message'] = 'The activation link is invalid or expired, or your account is already active.';

        $this->load->model('membership/activate_membership_model');
        if($this->activate_membership_model->activate_member(urldecode($email), $nonce)) {
            $content_data['message'] = 'Account has been activated.';
        }

        $this->template->set_theme(Settings_model::$db_config['default_theme']);
        $this->template->set_layout('main');
        $this->template->title('resend activation');
        $this->process_partial('header', 'membership/header');
        $this->process_partial('footer', 'membership/footer');
        $this->process_template_build('membership/activate_membership', $content_data);
    }

}

/* End of file activate_membership.php */
/* Location: ./application/controllers/membership/activate_membership.php */