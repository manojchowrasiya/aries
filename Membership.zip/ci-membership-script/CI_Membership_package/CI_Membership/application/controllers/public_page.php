<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Public_page extends Public_Controller {

    public function __construct()
    {
        parent::__construct();
        // pre-load
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    function index() {
        $this->template->set_theme(Settings_model::$db_config['default_theme']);
        $this->template->set_layout('main');
        $this->template->title('public page');
        $this->process_partial('header', 'public/header');
        $this->process_partial('footer', 'public/footer');
        $this->process_template_build('public_page');
    }

}

/* End of file public_page.php */
/* Location: ./application/controllers/public_page.php */