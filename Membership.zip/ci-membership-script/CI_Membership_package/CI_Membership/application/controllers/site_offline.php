<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_offline extends External_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    function index() {

        $this->template->set_theme(Settings_model::$db_config['default_theme']);
        $this->template->set_layout('main');
        $this->template->title('install');
        $this->process_partial('header', 'membership/header');
        $this->process_partial('footer', 'membership/footer');
        $this->process_template_build('site_offline');
    }

}

/* End of file site_offline.php */
/* Location: ./application/controllers/site_offline.php */