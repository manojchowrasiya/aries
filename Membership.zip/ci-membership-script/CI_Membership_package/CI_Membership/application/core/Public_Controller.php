<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Public_Controller extends MY_Controller
{
    public function __construct ()
    {
        parent::__construct();
    }
}

/* End of file Public_Controller.php */
/* Location: ./application/core/Public_Controller.php */